import React, { useEffect, useRef, useState } from 'react';

/** A compact, lazy-loaded Three.js cake. The parent keeps a CSS fallback visible until WebGL is ready. */
export default function CakeScene({ lit = 5, onReady = () => {} }) {
  const host = useRef(null);
  const litRef = useRef(lit);
  useEffect(() => { litRef.current = lit; }, [lit]);
  useEffect(() => {
    let renderer, frame, observer, disposed = false;
    let resize = () => {};
    import('three').then((THREE) => {
      if (disposed || !host.current) return;
      const width = host.current.clientWidth || 320;
      const height = host.current.clientHeight || 270;
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(34, width / height, .1, 100);
      camera.position.set(0, 3.8, 8.8);
      camera.lookAt(0, 1.05, 0);
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
      renderer.setSize(width, height);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      host.current.appendChild(renderer.domElement);
      scene.add(new THREE.HemisphereLight(0xffe9d1, 0x39202a, 2.1));
      const key = new THREE.PointLight(0xffc98c, 45, 18); key.position.set(-3, 6, 5); key.castShadow = true; scene.add(key);
      const fill = new THREE.PointLight(0xff8e79, 13, 14); fill.position.set(4, 2, -2); scene.add(fill);
      const mat = (color, roughness = .65, metalness = 0) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
      const makeCylinder = (radiusTop, radiusBottom, height, color, y, radial = 64) => {
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusTop, radiusBottom, height, radial), mat(color));
        mesh.position.y = y; mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh); return mesh;
      };
      makeCylinder(1.72, 1.8, .18, '#c6a47e', .12);
      makeCylinder(1.48, 1.48, .82, '#914b53', .62);
      makeCylinder(1.22, 1.22, .68, '#ead3b2', 1.34);
      makeCylinder(1.22, 1.22, .08, '#fff0d8', 1.72);
      const cream = mat('#f5e5ce');
      for (let i = 0; i < 12; i++) {
        const a = i * Math.PI / 6;
        const bead = new THREE.Mesh(new THREE.SphereGeometry(.055, 12, 10), cream);
        bead.position.set(1.25 * Math.cos(a), 1.35, 1.25 * Math.sin(a)); scene.add(bead);
      }
      const candleGroup = new THREE.Group(); scene.add(candleGroup);
      const candleMat = mat('#f2d9b7');
      const flameMat = new THREE.MeshBasicMaterial({ color: '#ffbf68' });
      const flameMeshes = [];
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        const x = .76 * Math.cos(a), z = .76 * Math.sin(a);
        const candle = new THREE.Mesh(new THREE.CylinderGeometry(.055, .06, .52, 12), candleMat);
        candle.position.set(x, 2.01, z); candle.castShadow = true; candleGroup.add(candle);
        const flame = new THREE.Mesh(new THREE.SphereGeometry(.09, 16, 12), flameMat.clone());
        flame.scale.set(.7, 1.5, .7); flame.position.set(x, 2.34, z); candleGroup.add(flame); flameMeshes.push(flame);
      }
      const ground = new THREE.Mesh(new THREE.CircleGeometry(4, 64), new THREE.ShadowMaterial({ opacity: .18 }));
      ground.rotation.x = -Math.PI / 2; ground.position.y = -.005; ground.receiveShadow = true; scene.add(ground);
      const group = new THREE.Group(); scene.add(group);
      for (let i = 0; i < 28; i++) {
        const a = i * 2.399, r = 2.1 + (i % 5) * .2;
        const star = new THREE.Mesh(new THREE.SphereGeometry(.018 + (i % 3) * .008, 8, 8), new THREE.MeshBasicMaterial({ color: i % 2 ? '#d9b987' : '#f4dfc2' }));
        star.position.set(Math.cos(a) * r, .5 + (i % 7) * .32, Math.sin(a) * r); group.add(star);
      }
      const clock = new THREE.Clock();
      const draw = () => { if (disposed) return; const t = clock.getElapsedTime(); candleGroup.rotation.y = Math.sin(t * .22) * .035; flameMeshes.forEach((f, i) => { f.visible = i < litRef.current; f.scale.y = .95 + Math.sin(t * 8 + i) * .18; }); group.rotation.y = t * .025; renderer.render(scene, camera); frame = requestAnimationFrame(draw); };
      resize = () => { if (!host.current || !renderer) return; const w = host.current.clientWidth || 320, h = host.current.clientHeight || 270; camera.aspect = w / h; camera.updateProjectionMatrix(); renderer.setSize(w, h); };
      observer = new ResizeObserver(resize); observer.observe(host.current); draw(); onReady(true);
    }).catch(() => onReady(false));
    return () => { disposed = true; cancelAnimationFrame(frame); observer?.disconnect(); window.removeEventListener('resize', resize); renderer?.dispose(); if (renderer?.domElement?.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement); };
  }, [onReady]);
  return <div className="three-cake-host" ref={host} aria-label="A softly lit three-dimensional birthday cake"/>;
}
