import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);
export function initScrollReveals() {
  const ctx = gsap.context(() => {
    gsap.utils.toArray('.memory-row, .section-heading, .intro-note, .gallery-tile').forEach((el) => {
      gsap.fromTo(el, { y: 28, opacity: 0 }, { y: 0, opacity: 1, duration: .85, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%', once: true } });
    });
  });
  return () => { ctx.revert(); ScrollTrigger.refresh(); };
}
