/**
 * PERSONALIZE YOUR SURPRISE HERE.
 * Replace the bracketed values before sharing the site.
 * PIN is a client-side surprise gate only, not real security.
 */
export const siteConfig = {
  girlfriendName: '[HER NAME]',
  senderName: '[YOUR NAME]',
  birthdayDate: '2026-12-01', // YYYY-MM-DD; set the real birthday
  specialDate: '',
  pin: '2026', // Change to any 4 digits. Never display this in the UI.
  heroMessage: 'Some people make the world feel a little softer. You are one of them.',
  birthdayMessage: 'I hope this next trip around the sun brings you the same warmth, joy, and kindness you bring into the lives around you. Keep being wonderfully, unmistakably you.',
  letter: `Happy birthday, my favourite person.\n\nI hope today reminds you how appreciated you are. I love the little things that make you who you are — your smile, your thoughtful heart, your quiet strength, and the way you can turn an ordinary day into a memory worth keeping.\n\nI may not always find the perfect words, but I hope you always feel how much you matter. May this year bring you peaceful mornings, exciting opportunities, good health, and countless reasons to smile.\n\nThank you for being you. Here's to more beautiful moments, at our own pace.\n\nWith all my love,\n[YOUR NAME]`,
  colors: { ink: '#1b1113', wine: '#4a202b', rose: '#bd7d79', ivory: '#f5eee4', gold: '#d9b987' },
  trackTitle: 'A little melody for you',
  artistName: 'Your birthday soundtrack',
  audioFile: '/audio/song.mp3', // Add your own licensed/local audio file to public/audio
  voiceMessage: '/audio/voice-message.mp3', // Optional; section stays hidden if missing
};

export const photos = {
  lockScreen: '/images/portrait-03.webp',
  intro: '/images/portrait-08.jpg',
  hero: '/images/portrait-01.webp',
  letter: '/images/portrait-06.jpg',
  finale: '/images/portrait-05.webp',
  timeline: ['/images/portrait-02.jpg', '/images/portrait-04.jpg', '/images/portrait-07.webp'],
  gallery: [
    '/images/portrait-01.webp', '/images/portrait-02.jpg', '/images/portrait-03.webp',
    '/images/portrait-04.jpg', '/images/portrait-05.webp', '/images/portrait-06.jpg',
    '/images/portrait-07.webp', '/images/portrait-08.jpg'
  ],
};
