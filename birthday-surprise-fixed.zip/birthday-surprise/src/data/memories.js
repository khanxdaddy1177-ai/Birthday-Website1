export const memories = [
  { date: 'A favourite chapter', title: 'The little things', text: 'The kind of moments that do not need a special occasion to become special.', image: '/images/portrait-02.jpg' },
  { date: 'A day to keep', title: 'A little sunshine', text: 'A reminder that the loveliest memories are often made in the simplest moments.', image: '/images/portrait-04.jpg' },
  { date: 'Always worth remembering', title: 'Just being you', text: 'Every version of you deserves to be celebrated — today and every day.', image: '/images/portrait-07.webp' },
];
export const appreciations = [
  ['Your kindness', 'You have a way of making people feel seen. That is a rare and beautiful thing.'],
  ['Your smile', 'It has a way of making even an ordinary moment feel lighter.'],
  ['Your strength', 'I admire how you keep showing up, growing, and finding your own way.'],
  ['Your little habits', 'The small details are often the things I end up remembering most.'],
  ['Your energy', 'You bring your own kind of light into every room and every story.'],
];
export const quiz = [
  { question: 'Which detail makes a memory feel unforgettable?', options: ['The little things', 'The perfect outfit', 'The fanciest place'], answer: 0 },
  { question: 'What deserves celebrating today?', options: ['Only big achievements', 'All the little and big things that make you, you', 'Just the cake'], answer: 1 },
  { question: 'What should this new year bring?', options: ['More stress', 'Less laughter', 'More joy, peace, and beautiful moments'], answer: 2 },
];
