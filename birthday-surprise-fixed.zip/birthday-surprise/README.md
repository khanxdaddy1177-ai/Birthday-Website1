# A Day For You — Birthday Surprise

A mobile-first, cinematic birthday story built with React, Vite, GSAP, Framer Motion and Three.js-ready dependencies. All supplied portraits are stored locally in `public/images`; they are not sent to an external image service.

## Personalize before sharing

Open **`src/config/siteConfig.js`** and update:

- `girlfriendName`, `senderName`
- `birthdayDate` (`YYYY-MM-DD`)
- `pin` (exactly four digits; this is only a playful client-side gate)
- `heroMessage`, `birthdayMessage`, `letter`
- `audioFile` and `voiceMessage` if you add local audio

Edit the memory cards, appreciation notes and quiz in **`src/data/memories.js`**. Replace or reorder the image paths in `photos` inside `siteConfig.js` to change which portrait appears in each chapter. The eight supplied images are already copied to `public/images/`.

## Add your own audio

Place a locally owned/licensed MP3 at `public/audio/song.mp3` and update `audioFile` if its name differs. The player will remain in its friendly empty state if no track is present. A voice-message path is reserved in the config and can be added as a future enhancement.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For a production build:

```bash
npm run build
npm run preview
```

The production output is written to `dist/`.

## Deploy to Vercel

Import the repository into Vercel. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`. No environment variables or API keys are required.

## Privacy

The site includes `noindex,nofollow`, has no analytics, no backend, and uses local assets. The PIN is visible to anyone who inspects the frontend bundle; do not use it to protect confidential material. For a private surprise, share the URL only with the intended recipient.

## Notes

- The birthday countdown uses the visitor's local browser clock.
- Photos are displayed without blur filters. `object-position` is tuned per section and can be adjusted in `global.css`.
- Gallery supports click/tap, keyboard arrows and Escape.
- Polaroids can be dragged on supported pointer devices.
- The cake attempts a lazy-loaded Three.js scene and falls back to a lightweight CSS illustration if WebGL is unavailable.
- Animations respect `prefers-reduced-motion`.
